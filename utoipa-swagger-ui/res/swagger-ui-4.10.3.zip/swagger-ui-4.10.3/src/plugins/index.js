import Configs from "./configs"
import Topbar from "./topbar"

export default {
  Configs,
  Topbar
}
